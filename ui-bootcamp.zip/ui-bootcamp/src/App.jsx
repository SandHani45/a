import React, {useEffect, useState} from "react";
import Header from "./components/Header";
import SearchUI from "./components/SearchUI";
import SearchResultsUI from './components/SearchResultsUI';
import data from './data/search.json'
const App = () => {
  const [searchInput, setSearchInput] = useState("")
  const [searchResult, setSearchResult] = useState([])
  
  const searchButton = () => {
   let resultData =  !!searchInput && data.filter(item => {
    return item.name.toUpperCase().includes(searchInput.toUpperCase())
   }) || []
    setSearchResult(resultData)
  }
 
  useEffect(()=>{
    setSearchResult(data)
  },[])
  const searchHandler = (e)=> setSearchInput(e.target.value);

  return (
    <>
      <Header />
      <div className="mainContainer">
         <SearchUI searchInput={searchInput} searchHandler={searchHandler} searchButton={searchButton}/>
          <div className="resultContainer">
            {searchResult && searchResult.map((items=>{
            return <SearchResultsUI title={items.name} descOne={"descOne"} address={items.address}/>
            }))}
          {!searchResult.length > 0 && <h1>No Result</h1>}
          </div>
         {/* Search Results  */}
         
      </div>
    </>
  );
};

export default App;
