import React, { useState } from 'react'
import './search.css'
const SearchUI = ({searchInput, searchHandler, searchButton}) => {
  return (
    <div className='searchMainContainer'>
      <div className="searchContainer" >
        <input type="text" name='searchInput'  value={searchInput} onChange={searchHandler} className='searchInput' aria-label="Dollar amount (with dot and two decimal places)" />
        <button type="button" class="btn btn-primary" onClick={searchButton}>Search</button>
        <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
               Sort
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Name</a></li>
                <li><a class="dropdown-item" href="#">City</a></li>
            </ul>
        </div>

    </div>
    </div>
  )
}

export default SearchUI