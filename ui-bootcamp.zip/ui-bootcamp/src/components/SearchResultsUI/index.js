import React from 'react'
import './searchResults.css'
export default function SearchResultsUI({title="", descOne="", tags=[], address}) {
  return (
    <div className='resultCardContainer'>
        <div className='avatarCard'>
          <div className='avatar'></div>
          <div className='cardDetails'>
            <h3>{title}</h3>
            <p>{descOne}</p>
            {tags.map(item=>{
              return ( <span> -{item}</span>)
            })}
          </div>
         
        </div>
        <div>
        <p>{address.address1}</p>
        <p>{address.address2}</p>
        </div>
          <div>
          <p>
            <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
              Show more
            </button>
          </p>
          <div class="collapse" id="collapseExample">
            <div class="card card-body">
              Some placeholder content for the collapse component. This panel is hidden by default but revealed when the user activates the relevant trigger.
            </div>
          </div>
          </div>
    </div>
  )
}
